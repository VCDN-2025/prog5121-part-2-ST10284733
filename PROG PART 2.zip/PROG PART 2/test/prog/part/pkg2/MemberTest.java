package prog.part.pkg2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pranay
 */
public class MemberTest {
    
    public MemberTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of checkID method, of class Member.
     */
    @Test
    public void testCheckID() {
        System.out.println("checkID");
        Member instance = null;
        boolean expResult = false;
        boolean result = instance.checkID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enrollMember method, of class Member.
     */
    @Test
    public void testEnrollMember() {
        System.out.println("enrollMember");
        Member instance = null;
        String expResult = "";
        String result = instance.enrollMember();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of accessMember method, of class Member.
     */
    @Test
    public void testAccessMember() {
        System.out.println("accessMember");
        String idInput = "";
        String nameInput = "";
        Member instance = null;
        boolean expResult = false;
        boolean result = instance.accessMember(idInput, nameInput);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of accessStatus method, of class Member.
     */
    @Test
    public void testAccessStatus() {
        System.out.println("accessStatus");
        boolean loginSuccess = false;
        Member instance = null;
        String expResult = "";
        String result = instance.accessStatus(loginSuccess);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
