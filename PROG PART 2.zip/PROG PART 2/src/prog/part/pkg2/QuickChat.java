package prog.part.pkg2;

import javax.swing.*;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

public class QuickChat {
    private static boolean isLoggedIn = false;
    private static int messageCounter = 0;
    private static List<String> sentMessages = new ArrayList<>();
    private static Member currentMember = null;

    public static void main(String[] args) {
        // Display welcome message
        JOptionPane.showMessageDialog(null, "WELCOME TO QUICKCHAT", "QuickChat", JOptionPane.INFORMATION_MESSAGE);

        // Login process
        login();

        if (isLoggedIn) {
            // Main application loop
            boolean running = true;
            while (running) {
                // Display menu
                String[] options = {"1) Send Messages", "2) Show recently sent messages", "3) Quit"};
                int choice = JOptionPane.showOptionDialog(null, 
                    "Please select an option:", 
                    "QuickChat Menu", 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.INFORMATION_MESSAGE, 
                    null, 
                    options, 
                    options[0]);

                switch (choice) {
                    case 0: // Send Messages
                        sendMessages();
                        break;
                    case 1: // Show recently sent messages
                        showRecentMessages();
                        break;
                    case 2: // Quit
                    case -1: // Closed the dialog
                        running = false;
                        break;
                }
            }
        }

        JOptionPane.showMessageDialog(null, "Thank you for using QuickChat!", "Goodbye", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void login() {
        String memberId = JOptionPane.showInputDialog(null, "Enter your member ID (format: MBR 12345):", "Login", JOptionPane.QUESTION_MESSAGE);
        String memberName = JOptionPane.showInputDialog(null, "Enter your name:", "Login", JOptionPane.QUESTION_MESSAGE);

        if (memberId == null || memberName == null) {
            return; // User cancelled
        }

        currentMember = new Member(memberId, memberName);
        
        // Validate member
        boolean isValid = currentMember.accessMember(memberId, memberName);
        String status = currentMember.accessStatus(isValid);
        
        if (isValid) {
            isLoggedIn = true;
            JOptionPane.showMessageDialog(null, "Login successful!\n" + status, "QuickChat", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Login failed.\n" + status, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void sendMessages() {
        if (!isLoggedIn) {
            JOptionPane.showMessageDialog(null, "You must be logged in to send messages.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Get number of messages to send
            String numStr = JOptionPane.showInputDialog(null, "How many messages do you want to send?", "Message Count", JOptionPane.QUESTION_MESSAGE);
            if (numStr == null) return; // User cancelled
            
            int numMessages = Integer.parseInt(numStr);
            if (numMessages <= 0) {
                JOptionPane.showMessageDialog(null, "Please enter a positive number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Send each message
            for (int i = 0; i < numMessages; i++) {
                sendSingleMessage();
            }

            // Display total messages sent
            JOptionPane.showMessageDialog(null, 
                "All messages sent!\nTotal messages sent in this session: " + messageCounter, 
                "QuickChat", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.", "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder allMessages = new StringBuilder();
        for (String msg : sentMessages) {
            allMessages.append(msg).append("\n\n");
        }
        
        JOptionPane.showMessageDialog(null, allMessages.toString(), "Recently Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void sendSingleMessage() {
        // Get recipient
        String recipient = JOptionPane.showInputDialog(null, "Enter recipient:", "New Message", JOptionPane.QUESTION_MESSAGE);
        if (recipient == null || recipient.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Recipient cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get message content
        String content = JOptionPane.showInputDialog(null, "Enter your message:", "New Message", JOptionPane.QUESTION_MESSAGE);
        if (content == null || content.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Message cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Generate message details
        messageCounter++;
        String messageId = "MSG-" + messageCounter;
        String hash = generateHash(content);

        // Store message details
        String messageDetails = String.format(
            "MessageID: %s\nMessage Hash: %s\nFrom: %s (%s)\nRecipient: %s\nMessage: %s",
            messageId, hash, currentMember.memberName, currentMember.memberID, recipient, content);
        sentMessages.add(messageDetails);

        // Display message details
        JOptionPane.showMessageDialog(null, messageDetails, "Message Sent", JOptionPane.INFORMATION_MESSAGE);
    }

    private static String generateHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(input.getBytes("UTF-8"));
            
            // Convert byte array to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return "Error generating hash";
        }
    }
}

class Member {
    String memberName;
    String memberID;

    public Member(String memberID, String memberName) {
        this.memberName = memberName;
        this.memberID = memberID;
    }

   
    public boolean checkID() {
        String regex = "MBR \\d{3,5}";
        return memberID.matches(regex);
    }

    public String enrollMember() {
        if (checkID()) {
            return "Member ID is valid. " + memberName + " registered successfully.";
        } else {
            return "Member ID not formatted correctly.";
        }
    }

    public boolean accessMember(String idInput, String nameInput) {
        boolean nameMatches = memberName.equalsIgnoreCase(nameInput);
        boolean idMatches = memberID.equalsIgnoreCase(idInput);
        return idMatches && nameMatches;
    }

  
    public String accessStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Access granted";
        } else {
            return "Access denied. Please check your member ID and name.";
        }
    }
}